export enum dataType {
    LoginDefaultEM,
    LoginDynamicEM,
    LoginEM,
    LoginDefaultDynamicEM,
    HostTableDataEM,
    AddOneDataEM,
    AttachTableDataEM,
    FixOneDataEM,
    FixMoreDataEM,
    DeleteOneDataEM,
    AddMoreAndFixMore,
    UnKnow
};