import { Component, OnInit } from '@angular/core';
import { BaseHttpService } from '../../../base-http-service/base-http.service'
import { RsuManageComponent } from '../rsu-edit/rsu-manage.component'

@Component({
  selector: 'app-team-edit',
  templateUrl: './team-edit.component.html',
  styleUrls: ['./team-edit.component.scss']
})
export class TeamEditComponent extends RsuManageComponent implements OnInit {

  url: string = '';
  requestParams: any = {};
  requestDataType: number = -1;

  constructor(_http: BaseHttpService) {
    super(_http);
  }

  ngOnInit() {
    this.filterColArr = ['C3_561545942716', 'C3_561545942872', 'C3_561545943044', 'C3_561550147088', 'C3_561550169926',];
    this.sortColArr = ['C3_561545941733', 'C3_561549939294']
    this.sortColArr.forEach(col => {
      this.sortMap[col] = null
    });
    this.sumColArr = ['C3_561550223794', 'C3_561571697273'];

    let path = this._http.path;
    const moneyUrl = path.baseUrl + path.getData;
    const moneyParams = {
      resid: 561571034816
    }
    this._http.baseRequest("GET", moneyUrl, moneyParams, this._http.dataT.HostTableDataEM).subscribe(
      data => {
        console.log("money Data", data)
        if (data && data['data'] && Array.isArray(data['data']) && data['data'][0]) {
          // setTimeout(() => {

          this.moneyProportion = data['data'][0]['C3_561550600104'];
          // }, 20000);
        }
      },
      error => {

      }
    )


    let url = path.loginBaseUrl + path.getData;
    let params = {
      resid: 561571882590,
      getcolumninfo: 1
    }
    this._http.baseRequest("GET", url, params, this._http.dataT.HostTableDataEM).subscribe(
      data => {
        if (data && data['data'] && Array.isArray(data['data'])) {
          this._titleArr = data['cmscolumninfo'];
          this._data = data['data'];
          this.copyData = [...this._data];

          this.filterColArr.forEach(col => {
            this.filterArrayMap[col] = this.getFilterArrData(this.copyData, col);
          })
          console.info(this.filterArrayMap)

        }
      },
      error => {
        console.error(error);
      }
    )
  }

  getDiffMoney() {
    let diffNum = Number(this.getColSumMoney('C3_561550223794')) - Number(this.getColSum('C3_561571697273'));
    return diffNum.toFixed(2);
  }

  submitClick() {
    let path = this._http.path;
    let url = path.baseUrl + path.saveData;
    let submitData = [];
    for (var i = 0; i < 1; i++) {
      let item = this.copyData[i];
      submitData.push({
        C3_561571697273: item['C3_561571697273'],
        C3_561571761141: 'Y',
        REC_ID: item['REC_ID']
      })
    }
    let params = {
      resid: 561571882590,
      data: submitData,
      withoutdata: 1,
      formulalayer: 0
    }
    this._http.baseRequest("POST", url, params, this._http.dataT.FixMoreDataEM).subscribe(
      data => {
        console.info(data)
        if (data && data.error == 0) {


        }
      },
      error => {
        console.error(error);
      }
    )
  }

}
